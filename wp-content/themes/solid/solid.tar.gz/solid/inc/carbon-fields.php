<?php

	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	use Carbon_Fields\Container;
	use Carbon_Fields\Field;


	/**
	 * Options Page
	 */

	add_action( 'carbon_fields_register_fields', 'solid_theme_options' );

	function solid_theme_options() {
		Container::make( 'theme_options', 'Опції сайту')
		         ->set_icon( 'dashicons-admin-generic' )
		         ->add_fields( array(
			         Field::make( 'text', 'crb_text', 'Text Field' ),
		         ) );
	}

	/**
	 * Course Page
	 */

	add_action( 'carbon_fields_register_fields', 'course_page_fields' );

	function course_page_fields(){

		Container::make( 'post_meta', 'Головний екран' )
		         ->where( function( $homeFields ) {
			         $homeFields->where( 'post_type', '=', 'page' );
			         $homeFields->where( 'post_template', '=', 'template-course.php' );
		         } )

		         ->add_fields( array(
			         Field::make( 'textarea', 'main_call'.carbon_lang_prefix(), 'Текст заклику'  )
				            ->set_attribute( 'placeholder', __( 'Твоя кар`єрна підтримка у світі ІТ.  Розберись у технічній англійській та підвищуй  свою конкурентоспроможність.' ) )
				            ->set_help_text( 'Якщо потрібно зробити примусовий переніс строки, перед текстом який має починатися з наступної строки треба поставити тег &lt;/br&gt')
				            ->set_rows( 4 ),
			         Field::make( 'text', 'main_course_start_text'.carbon_lang_prefix(), 'Текст "Дата старту курсу"'  )
				            ->set_attribute( 'placeholder', __( 'Дата старту курсу' ) ),
			         Field::make( 'complex', 'main_curse_start_data_list'.carbon_lang_prefix(), 'Вкажіть жати початку курсу' )
			              ->add_fields( array(
				              Field::make( 'date', 'start_date', 'Дата початку' )
				                   ->set_attribute( 'placeholder', __( '15.08.23' ) )
				                   ->set_storage_format( 'd.m.y' ),
			              ) ),
			         Field::make( 'text', 'main_course_schedule_text'.carbon_lang_prefix(), 'Текст "Графік"'  )
				            ->set_attribute( 'placeholder', __( 'Графік' ) ),
			         Field::make( 'text', 'main_course_schedule'.carbon_lang_prefix(), 'Графік курсу'  )
				            ->set_attribute( 'placeholder', __( 'ПН, СР, ПТ 18:00 - 19:00' ) ),
			         Field::make( 'text', 'main_form_title'.carbon_lang_prefix(), 'Заголовок форми'  )
				            ->set_attribute( 'placeholder', __( 'Поглиблюй розуміння ІТ термінів та освоюй англійську документацію. Відчуй себе впевнено 
на англомовних зустрічах' ) ),
			         Field::make( 'text', 'main_form_call'.carbon_lang_prefix(), 'Заклик заповнити форму'  )
				            ->set_attribute( 'placeholder', __( 'Заповнюй свої контактні дані для консультації' ) ),
			         Field::make( 'text', 'main_form_submit_text'.carbon_lang_prefix(), 'Текст кнопки у формі'  )
				            ->set_attribute( 'placeholder', __( 'Замовити консультацію' ) ),

		         ));

		Container::make( 'post_meta', 'Блок № 1' )
		         ->where( function( $homeFields ) {
			         $homeFields->where( 'post_type', '=', 'page' );
			         $homeFields->where( 'post_template', '=', 'template-course.php' );
		         } )

		         ->add_fields( array(
			         Field::make( 'radio', 'solid_block_1_question'.carbon_lang_prefix(), __('Оберіть який блок відображати') )
			              ->set_options( array(
				              'course_info' => __('Блок "Інформація про курс"'),
				              'teachers' => __('Блок "Вчителі"'),
				              'free_class' => __('Блок "Пробне заняття"'),
				              'infographics' => __('Блок "Інфографіка"'),
				              'course_topics' => __('Блок "Теми курсу"'),
				              'call_quiz' => __('Блок "Призов пройти опитування"'),
				              'reviews' => __('Блок "Відгуки"'),
				              'off' => __('Вимкнути'),

			              ) ),

			         /**
			          * Блок "Інформація про курс"
			          */
			         Field::make( 'text', 'solid_block_1_course_info_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
				         ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_info',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_course_info_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Курс англійської IT STARTER' ) )
				            ->set_conditional_logic( array(
					            'relation' => 'AND',
					            array(
						            'field' => 'solid_block_1_question'.carbon_lang_prefix(),
						            'value' => 'course_info',
						            'compare' => '=',
					            )
				            ) ),
			         Field::make( 'complex', 'solid_block_1_course_info_about'.carbon_lang_prefix(), 'Перелік інформаціїних блоків про курс' )
						        ->set_conditional_logic( array(
							        'relation' => 'AND',
							        array(
								        'field' => 'solid_block_1_question'.carbon_lang_prefix(),
								        'value' => 'course_info',
								        'compare' => '=',
							        )
						        ) )
			              ->add_fields( array(
				              Field::make( 'image', 'icon', 'Іконка блоку' )
				                   ->set_value_type( 'url' ),
				              Field::make( 'complex', 'info_items', 'Перелік інформації' )
				                   ->add_fields( array(
					                   Field::make( 'text', 'info_name', 'Назва'  )
						                   ->set_attribute( 'placeholder', __( 'Кількість занятть у курсі' ) ),
					                   Field::make( 'text', 'info_value', 'Значення'  )
						                   ->set_attribute( 'placeholder', __( '24' ) ),
				                   ) )
			              ) ),
			         Field::make( 'text', 'solid_block_1_course_info_sub_title'.carbon_lang_prefix(), 'Підзаголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Зміцни навички та отримай переваги разом з Solid' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_info',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'complex', 'solid_block_1_course_info_advantages'.carbon_lang_prefix(), 'Перелік переваг' )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_info',
					              'compare' => '=',
				              )
			              ) )
				            ->add_fields( array(
					            Field::make( 'image', 'advantage_icon', 'Іконка блоку' )
					                 ->set_value_type( 'url' ),
					            Field::make( 'text', 'advantage_name', 'Назва'  )
						               ->set_attribute( 'placeholder', __( '24 онлайн заняття' ) ),
					            Field::make( 'textarea', 'advantage_description', 'Оптс'  )
						               ->set_attribute( 'placeholder', __( 'На уроках ти будеш вивчати IT лексику та граматику на реальних прикладах комунікації в IT' ) )
					                 ->set_rows( 4 ),

				            ) ),
			         /**
			          * Блок "Вчителі"
			          */
			         Field::make( 'text', 'solid_block_1_teachers_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'teachers',
					              'compare' => '=',
				              )
			              ) ),

			         Field::make( 'text', 'solid_block_1_teachers_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Наша методологія та професійні вчителі: ключ до успішного вивчення англійської' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'teachers',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'textarea', 'solid_block_1_teachers_text'.carbon_lang_prefix(), 'Текст блоку'  )
				             ->set_attribute( 'placeholder', __( 'Тіччери з досвідом та міжнародними сертифікатами CELTA, TESOL, TKT, IELTS, CAE привносять унікальність у наш підхід до навчання. Вони не тільки жили за кордоном та спілкувалися з носіями мови, а й постійно вдосконалюють свої навички на тренінгах, семінарах та конференціях.' ) )
			              ->set_help_text( 'Якщо потрібно зробити примусовий переніс строки, перед текстом який має починатися з наступної строки треба поставити тег &lt;/br&gt')
			              ->set_rows( 4 )
				            ->set_conditional_logic( array(
					            'relation' => 'AND',
					            array(
						            'field' => 'solid_block_1_question'.carbon_lang_prefix(),
						            'value' => 'teachers',
						            'compare' => '=',
					            )
				            ) ),
			         Field::make( 'text', 'solid_block_1_teachers_slogan'.carbon_lang_prefix(), 'Слоган'  )
				            ->set_attribute( 'placeholder', __( 'Для нас навчання англійської - це не просто робота, а стиль життя та пристрасть, яку ми з ентузіазмом передаємо нашим студентам.' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'teachers',
					              'compare' => '=',
				              )
			              ) ),

			         /**
			          * Блок "Пробне заняття"
			          */
			         Field::make( 'text', 'solid_block_1_free_class_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'free_class',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_free_class_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Спробуй безкоштовне пробне заняття із курсу IT Starter. Отримай унікальну можливість випробувати наше пробне заняття з курсу IT Starter.' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'free_class',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'textarea', 'solid_block_1_free_class_text'.carbon_lang_prefix(), 'Текст блоку'  )
				            ->set_attribute( 'placeholder', __( 'Поглибь свої знання в області ІТ та оціни якість нашого навчання.
Розпочни свій шлях до успішної ІТ кар`єри з англомовними проектами вже сьогодні' ) )
			              ->set_help_text( 'Якщо потрібно зробити примусовий переніс строки, перед текстом який має починатися з наступної строки треба поставити тег &lt;/br&gt')
			              ->set_rows( 4 )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'free_class',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'complex', 'solid_block_1_free_class_info_blocks'.carbon_lang_prefix(), 'Перелік блоків з інформацією' )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'free_class',
					              'compare' => '=',
				              )
			              ) )
			              ->add_fields( array(
				              Field::make( 'text', 'info_name', 'Назва'  )
					                 ->set_attribute( 'placeholder', __( 'Цей курс підійде тобі, якщо ти' ) ),
				              Field::make( 'complex', 'info_items', 'Перелік інформації' )
				                   ->add_fields( array(
					                   Field::make( 'text', 'info_name', 'Текст'  )
						                   ->set_attribute( 'placeholder', __( 'Тільки починаєш кар`єру IT' ) ),
				                   ) )
			              ) ),
			         Field::make( 'text', 'solid_block_1_free_class_form_btn'.carbon_lang_prefix(), 'Текст кнопки у формі'  )
				         ->set_attribute( 'placeholder', __( 'Пробне заняття' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'free_class',
					              'compare' => '=',
				              )
			              ) ),

			         /**
			          * Блок "Інфографіка"
			          */
			         Field::make( 'text', 'solid_block_1_infographics_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'infographics',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_infographics_list_title'.carbon_lang_prefix(), 'Назва переріку'  )
				            ->set_attribute( 'placeholder', __( 'Переваги навчання у Solid ES' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'infographics',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'complex', 'solid_block_1_infographics_list'.carbon_lang_prefix(), 'Перелік' )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'infographics',
					              'compare' => '=',
				              )
			              ) )
			              ->add_fields( array(
				              Field::make( 'text', 'list_item', 'Текст'  )
					                 ->set_attribute( 'placeholder', __( 'Профільна технічна англійська' ) ),
			              ) ),

			         /**
			          * Блок "Теми курсу"
			          */
			         Field::make( 'text', 'solid_block_1_course_topics_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_topics',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_course_topics_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( '24 теми уроків курсу "IT Starter" зосереджені на спеціалізованій тематиці ІТ' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_topics',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'complex', 'solid_block_1_course_topics_list'.carbon_lang_prefix(), 'Перелік' )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'course_topics',
					              'compare' => '=',
				              )
			              ) )
			              ->add_fields( array(
				              Field::make( 'text', 'list_item', 'Текст'  )
					                 ->set_attribute( 'placeholder', __( 'Problem-solving' ) ),
			              ) ),

			         /**
			          * Блок "Призов пройти опитування"
			          */
			         Field::make( 'text', 'solid_block_1_call_quiz_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_call_quiz_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Не можеш визначитись з програмою навчання? ' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'textarea', 'solid_block_1_call_quiz_text'.carbon_lang_prefix(), 'Текст блоку'  )
				            ->set_attribute( 'placeholder', __( 'Пройди безкоштовне тестування рівня англійської мови та отримай індивідуальні рекомендації щодо найкращого курсу' ) )
			              ->set_help_text( 'Якщо потрібно зробити примусовий переніс строки, перед текстом який має починатися з наступної строки треба поставити тег &lt;/br&gt')
			              ->set_rows( 4 )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_call_quiz_call_btn'.carbon_lang_prefix(), 'Текст заклику натиснути кнопку'  )
				            ->set_attribute( 'placeholder', __( 'Пройти онлайн тестування
та отримати індивідуальні рекомендації' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_call_quiz_btn_text'.carbon_lang_prefix(), 'Текст кнопки'  )
				            ->set_attribute( 'placeholder', __( 'Пройти тест' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_call_quiz_btn_link'.carbon_lang_prefix(), 'Посилання у кнопку'  )
				            ->set_attribute( 'placeholder', __( 'https://solid.com.ua/' ) )
				            ->set_attribute( 'type', 'url' )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'call_quiz',
					              'compare' => '=',
				              )
			              ) ),
			         /**
			          * Блок "Відгуки"
			          */
			         Field::make( 'text', 'solid_block_1_reviews_id'.carbon_lang_prefix(), 'Ідентифікатор блоку'  )
			              ->set_help_text( 'Потрібен для прив`язки блоку для міню навігації по сторінці та аналітики')
			              ->set_attribute( 'placeholder', __( 'block-id' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'reviews',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'text', 'solid_block_1_reviews_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
				            ->set_attribute( 'placeholder', __( 'Думки наших студентів: Відгуки про Курси англійської для ІТ' ) )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question'.carbon_lang_prefix(),
					              'value' => 'reviews',
					              'compare' => '=',
				              )
			              ) ),
			         Field::make( 'textarea', 'solid_block_1_reviews_text'.carbon_lang_prefix(), 'Текст блоку'  )
				            ->set_attribute( 'placeholder', __( 'Відкрий світ думок та вражень наших задоволених студентів, які вже успішно пройшли Курси англійської для ІТ.Вони діляться своїми враженнями, досягненнями та перевагами, які отримали завдяки цим курсам. Дізнайся, як наші програми допомогли їм покращити рівень англійської, отримати нові можливості та розширити свої професійні горизонти.' ) )
			              ->set_help_text( 'Якщо потрібно зробити примусовий переніс строки, перед текстом який має починатися з наступної строки треба поставити тег &lt;/br&gt')
			              ->set_rows( 4 )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_1_question',
					              'value' => 'reviews',
					              'compare' => '=',
				              )
			              ) ),

		         ));



		Container::make( 'post_meta', 'Блок № 2' )
		         ->where( function( $homeFields ) {
			         $homeFields->where( 'post_type', '=', 'page' );
			         $homeFields->where( 'post_template', '=', 'template-course.php' );
		         } )

		         ->add_fields( array(
			         Field::make( 'radio', 'solid_block_2_question'.carbon_lang_prefix(), __('Оберіть який блок відображати') )
			              ->set_options( array(
				              'course_info' => __('Блок "Інформація про курс"'),
				              'teachers' => __('Блок "Вчителі"'),
				              'free_class' => __('Блок "Пробне заняття"'),
				              'infographics' => __('Блок "Інфографіка"'),
				              'course_topics' => __('Блок "Теми курс"'),
				              'call' => __('Блок "Призив до дії"'),
				              'reviews' => __('Блок "Відгуки"'),
				              'off' => __('Вимкнути'),

			              ) ),
			         Field::make( 'text', 'solid_block_2_course_info_title'.carbon_lang_prefix(), 'Заголовок блоку'  )
			              ->set_conditional_logic( array(
				              'relation' => 'AND',
				              array(
					              'field' => 'solid_block_2_question'.carbon_lang_prefix(),
					              'value' => 'course_info',
					              'compare' => '=',
				              )
			              ) ),

		         ));
		/**
		 * Інтеграція з CRM
		 */

		Container::make( 'post_meta', 'Інтеграція курсу з One Box' )
		         ->where( function( $homeFields ) {
			         $homeFields->where( 'post_type', '=', 'page' );
			         $homeFields->where( 'post_template', '=', 'template-course.php' );
		         } )

		         ->add_fields( array(

			         Field::make( 'text', 'integration_course_id'.carbon_lang_prefix(), 'ID продукту'  )


		         ));

	}
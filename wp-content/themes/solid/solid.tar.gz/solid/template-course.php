<?php

	if ( ! defined( 'ABSPATH' ) ) {
		exit;
	}

	/**
	 * Template part for displaying page content in page.php
	 *
	 * Template name: Template Course Page
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
	 *
	 * @package solid
	 *
	 */

	get_header();
	?>

<?php
	$block_1 = carbon_get_post_meta( get_the_ID(), 'solid_block_1_question'.carbon_lang_prefix() );
	$block_2 = carbon_get_post_meta( get_the_ID(), 'solid_block_2_question'.carbon_lang_prefix() );
	$block_3 = carbon_get_post_meta( get_the_ID(), 'solid_block_3_question'.carbon_lang_prefix() );
	$block_4 = carbon_get_post_meta( get_the_ID(), 'solid_block_4_question'.carbon_lang_prefix() );
	$block_5 = carbon_get_post_meta( get_the_ID(), 'solid_block_5_question'.carbon_lang_prefix() );
	$block_6 = carbon_get_post_meta( get_the_ID(), 'solid_block_6_question'.carbon_lang_prefix() );
	$block_7 = carbon_get_post_meta( get_the_ID(), 'solid_block_7_question'.carbon_lang_prefix() );
	$block_8 = carbon_get_post_meta( get_the_ID(), 'solid_block_8_question'.carbon_lang_prefix() );

	echo carbon_lang_prefix();
	echo get_the_ID();


	if ( $block_1 == 'course_info' ){

		echo

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'course-info', $prefix);

	}elseif ( $block_1 == 'teachers' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'teachers', $prefix);

	}elseif ( $block_1 == 'free_class' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'free-class', $prefix);

	}elseif ( $block_1 == 'infographics' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'infographics', $prefix);

	}elseif ( $block_1 == 'course_topics' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'course-topics', $prefix);

	}elseif ( $block_1 == 'call_quiz' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'call-quiz', $prefix);

	}elseif ( $block_1 == 'reviews' ){

		$prefix = 'solid_block_1_';
		get_template_part('template-parts/block', 'reviews', $prefix);
	}

	if ($block_2 == 'course_info'){

		$prefix = 'solid_block_2_';
		get_template_part('template-parts/block', 'course-info', $prefix);

	}

?>
<?php get_footer();

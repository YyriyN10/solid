
<?php
	$blockTitle = carbon_get_post_meta( get_the_ID(), ''.$args.'course_info_title'.carbon_lang_prefix() );

?>
	<!-- Courses info -->
	<section class="">
	  <div class="container">
	    <div class="row">
	      <h2 class="block-title"><?php echo $blockTitle;?></h2>
	    </div>
	    <div class="row">
	      <div class="content col-12">
	        <div class="item">

	        </div>
	      </div>
	    </div>
	  </div>
	</section>